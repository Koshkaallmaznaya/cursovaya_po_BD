<?php
require_once("dbConnection.php");
$id = $_GET['id'];
$result = mysqli_query($mysqli, 
"SELECT bilets.prodano, films.summa, bilets.stoimost, films.id_film
FROM bilets JOIN films ON bilets.id_film=films.id_film
WHERE bilets.id_bilet=$id");
$resultData = mysqli_fetch_assoc($result);
$prodano = $resultData['prodano'];
$summa = $resultData['summa'];
$stoimost = $resultData['stoimost'];
$id_f = $resultData['id_film'];
$summa2 = $summa + $stoimost;
$prodano_update = mysqli_query($mysqli, "UPDATE bilets SET prodano = '1' WHERE id_bilet = $id");
$summa_update = mysqli_query($mysqli, "UPDATE films SET summa = $summa2 WHERE id_film = $id_f");
header("Location:index.php");
?>