<?php
require_once("dbConnection.php");
$result = mysqli_query($mysqli, "SELECT * FROM films ORDER BY summa DESC");
?>

<html lang="ru">
<head>
    <meta charset="UTF-8">
    <link href="main.css" rel="stylesheet">
	<title>Фильмы</title>
</head>

<body>
    <h1>Фильмы</h1>

    <table width='80%'>
		<tr class="hat">
            <td><strong>Место</strong></td>
			<td><strong>Фильм</strong></td>
			<td><strong>Сумма сборов</strong></td>
		</tr>
		<?php
        $count = 0;
		while ($res = mysqli_fetch_assoc($result)) {
            $count = $count + 1;
            echo "<tr>";
            echo "<td>".$count."</td>";
            echo "<td><a href=\"seans.php?id=$res[id_film]\">".$res['name_film']."</a>";
			echo "<td>".$res['summa']."</td>";
			echo "</tr>";
		}
		?>
	</table>
</body>
</html>