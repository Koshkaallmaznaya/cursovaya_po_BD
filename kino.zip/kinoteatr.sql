-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Июл 10 2023 г., 14:01
-- Версия сервера: 8.0.30
-- Версия PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `kinoteatr`
--

-- --------------------------------------------------------

--
-- Структура таблицы `bilets`
--

CREATE TABLE `bilets` (
  `id_bilet` int UNSIGNED NOT NULL,
  `id_film` int UNSIGNED NOT NULL,
  `id_zal` int UNSIGNED NOT NULL,
  `id_seans` int UNSIGNED DEFAULT NULL,
  `ryad` int UNSIGNED NOT NULL,
  `mesto` int UNSIGNED NOT NULL,
  `stoimost` int UNSIGNED NOT NULL,
  `prodano` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `bilets`
--

INSERT INTO `bilets` (`id_bilet`, `id_film`, `id_zal`, `id_seans`, `ryad`, `mesto`, `stoimost`, `prodano`) VALUES
(4, 1, 1, 1, 1, 1, 100, NULL),
(5, 1, 1, 1, 1, 2, 100, NULL),
(6, 1, 1, 1, 1, 3, 100, NULL),
(7, 1, 1, 1, 1, 4, 100, NULL),
(8, 1, 1, 1, 2, 1, 200, NULL),
(9, 1, 1, 1, 2, 2, 200, NULL),
(10, 1, 1, 1, 2, 3, 200, NULL),
(11, 1, 1, 1, 2, 4, 200, NULL),
(12, 1, 1, 1, 3, 1, 300, NULL),
(13, 1, 1, 1, 3, 2, 300, NULL),
(14, 1, 1, 1, 3, 3, 300, NULL),
(15, 1, 1, 1, 3, 4, 300, NULL),
(16, 1, 2, 2, 1, 1, 100, NULL),
(17, 1, 2, 2, 1, 2, 100, NULL),
(18, 1, 2, 2, 1, 3, 100, NULL),
(19, 1, 2, 2, 2, 1, 200, NULL),
(20, 1, 2, 2, 2, 2, 200, NULL),
(21, 1, 2, 2, 2, 3, 200, NULL),
(22, 5, 1, 5, 1, 1, 100, NULL),
(23, 5, 1, 5, 1, 2, 100, NULL),
(24, 5, 1, 5, 1, 3, 100, NULL),
(25, 5, 1, 5, 1, 4, 100, NULL),
(26, 5, 1, 5, 2, 1, 200, NULL),
(27, 5, 1, 5, 2, 2, 200, NULL),
(28, 5, 1, 5, 2, 3, 200, NULL),
(29, 5, 1, 5, 2, 4, 200, NULL),
(30, 5, 1, 5, 3, 1, 300, NULL),
(31, 5, 1, 5, 3, 2, 300, NULL),
(32, 5, 1, 5, 3, 3, 300, NULL),
(33, 5, 1, 5, 3, 4, 300, NULL),
(34, 5, 2, 6, 1, 1, 100, NULL),
(35, 5, 2, 6, 1, 2, 100, NULL),
(36, 5, 2, 6, 1, 3, 100, NULL),
(37, 5, 2, 6, 2, 1, 200, NULL),
(38, 5, 2, 6, 2, 2, 200, NULL),
(39, 5, 2, 6, 2, 3, 200, NULL),
(40, 7, 1, 10, 1, 1, 100, NULL),
(41, 7, 1, 10, 1, 2, 100, NULL),
(42, 7, 1, 10, 1, 3, 100, NULL),
(43, 7, 1, 10, 1, 4, 100, NULL),
(44, 7, 1, 10, 2, 1, 200, NULL),
(45, 7, 1, 10, 2, 2, 200, NULL),
(46, 7, 1, 10, 2, 3, 200, NULL),
(47, 7, 1, 10, 2, 4, 200, NULL),
(48, 7, 1, 10, 3, 1, 300, NULL),
(49, 7, 1, 10, 3, 2, 300, NULL),
(50, 7, 1, 10, 3, 3, 300, NULL),
(51, 7, 1, 10, 3, 4, 300, NULL),
(52, 7, 2, 9, 1, 1, 100, NULL),
(53, 7, 2, 9, 1, 2, 100, NULL),
(54, 7, 2, 9, 1, 3, 100, NULL),
(55, 7, 2, 9, 2, 1, 200, NULL),
(56, 7, 2, 9, 2, 2, 200, NULL),
(57, 7, 2, 9, 2, 3, 200, NULL),
(58, 2, 1, 3, 1, 1, 100, NULL),
(59, 2, 1, 3, 1, 2, 100, NULL),
(60, 2, 1, 3, 1, 3, 100, NULL),
(61, 2, 1, 3, 1, 4, 100, NULL),
(62, 2, 1, 3, 2, 1, 200, NULL),
(63, 2, 1, 3, 2, 2, 200, NULL),
(64, 2, 1, 3, 2, 3, 200, NULL),
(65, 2, 1, 3, 2, 4, 200, NULL),
(66, 2, 1, 3, 3, 1, 300, NULL),
(67, 2, 1, 3, 3, 2, 300, NULL),
(68, 2, 1, 3, 3, 3, 300, NULL),
(69, 2, 1, 3, 3, 4, 300, NULL),
(70, 2, 1, 4, 1, 1, 100, NULL),
(71, 2, 1, 4, 1, 2, 100, NULL),
(72, 2, 1, 4, 1, 3, 100, NULL),
(73, 2, 1, 4, 1, 4, 100, NULL),
(74, 2, 1, 4, 2, 1, 200, NULL),
(75, 2, 1, 4, 2, 2, 200, NULL),
(76, 2, 1, 4, 2, 3, 200, NULL),
(77, 2, 1, 4, 2, 4, 200, NULL),
(78, 2, 1, 4, 3, 1, 300, NULL),
(79, 2, 1, 4, 3, 2, 300, NULL),
(80, 2, 1, 4, 3, 3, 300, NULL),
(81, 2, 1, 4, 3, 4, 300, NULL),
(82, 6, 2, 7, 1, 1, 100, NULL),
(83, 6, 2, 7, 1, 2, 100, NULL),
(84, 6, 2, 7, 1, 3, 100, NULL),
(85, 6, 2, 7, 2, 1, 200, NULL),
(86, 6, 2, 7, 2, 2, 200, NULL),
(87, 6, 2, 7, 2, 3, 200, NULL),
(88, 6, 2, 8, 1, 1, 100, NULL),
(89, 6, 2, 8, 1, 2, 100, NULL),
(90, 6, 2, 8, 1, 3, 100, NULL),
(91, 6, 2, 8, 2, 1, 200, NULL),
(92, 6, 2, 8, 2, 2, 200, NULL),
(93, 6, 2, 8, 2, 3, 200, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `films`
--

CREATE TABLE `films` (
  `id_film` int UNSIGNED NOT NULL,
  `name_film` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `summa` int UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `films`
--

INSERT INTO `films` (`id_film`, `name_film`, `summa`) VALUES
(1, 'Стражи галактики', 0),
(2, 'Мастер и Маргарита', 0),
(5, 'Начало', 0),
(6, 'Легенда', 0),
(7, 'Хроники нарнии', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `seanses`
--

CREATE TABLE `seanses` (
  `id_seans` int UNSIGNED NOT NULL,
  `id_film` int UNSIGNED DEFAULT NULL,
  `date_seans` datetime NOT NULL,
  `id_zal` int UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `seanses`
--

INSERT INTO `seanses` (`id_seans`, `id_film`, `date_seans`, `id_zal`) VALUES
(1, 1, '2023-08-10 10:10:00', 1),
(2, 1, '2023-08-12 12:00:00', 2),
(3, 2, '2023-08-10 10:10:00', 1),
(4, 2, '2023-08-11 15:20:00', 1),
(5, 5, '2023-08-05 13:00:00', 1),
(6, 5, '2023-08-05 13:00:00', 2),
(7, 6, '2023-08-17 17:22:00', 2),
(8, 6, '2023-08-19 17:00:00', 2),
(9, 7, '2023-08-15 10:00:00', 2),
(10, 7, '2023-08-13 10:00:00', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `zals`
--

CREATE TABLE `zals` (
  `id_zal` int UNSIGNED NOT NULL,
  `name_zal` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `zals`
--

INSERT INTO `zals` (`id_zal`, `name_zal`) VALUES
(1, 'Большой'),
(2, 'Малый');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `bilets`
--
ALTER TABLE `bilets`
  ADD PRIMARY KEY (`id_bilet`),
  ADD KEY `id_film` (`id_film`),
  ADD KEY `id_seans` (`id_seans`),
  ADD KEY `id_zal` (`id_zal`);

--
-- Индексы таблицы `films`
--
ALTER TABLE `films`
  ADD PRIMARY KEY (`id_film`),
  ADD UNIQUE KEY `name_film` (`name_film`);

--
-- Индексы таблицы `seanses`
--
ALTER TABLE `seanses`
  ADD PRIMARY KEY (`id_seans`),
  ADD KEY `id_film` (`id_film`),
  ADD KEY `id_zal` (`id_zal`);

--
-- Индексы таблицы `zals`
--
ALTER TABLE `zals`
  ADD PRIMARY KEY (`id_zal`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `bilets`
--
ALTER TABLE `bilets`
  MODIFY `id_bilet` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=94;

--
-- AUTO_INCREMENT для таблицы `films`
--
ALTER TABLE `films`
  MODIFY `id_film` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `seanses`
--
ALTER TABLE `seanses`
  MODIFY `id_seans` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `zals`
--
ALTER TABLE `zals`
  MODIFY `id_zal` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `bilets`
--
ALTER TABLE `bilets`
  ADD CONSTRAINT `bilets_ibfk_1` FOREIGN KEY (`id_film`) REFERENCES `films` (`id_film`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `bilets_ibfk_3` FOREIGN KEY (`id_seans`) REFERENCES `seanses` (`id_seans`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `bilets_ibfk_4` FOREIGN KEY (`id_zal`) REFERENCES `zals` (`id_zal`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Ограничения внешнего ключа таблицы `seanses`
--
ALTER TABLE `seanses`
  ADD CONSTRAINT `seanses_ibfk_3` FOREIGN KEY (`id_film`) REFERENCES `films` (`id_film`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  ADD CONSTRAINT `seanses_ibfk_4` FOREIGN KEY (`id_zal`) REFERENCES `zals` (`id_zal`) ON DELETE RESTRICT ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
