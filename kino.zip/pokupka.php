<?php
require_once("dbConnection.php");
$id = $_GET['id'];
$result = mysqli_query($mysqli, 
"SELECT bilets.ryad, bilets.mesto, bilets.stoimost, bilets.id_bilet
FROM bilets JOIN zals ON bilets.id_zal=zals.id_zal
JOIN seanses ON seanses.id_seans=bilets.id_seans
WHERE bilets.id_seans=$id AND bilets.prodano IS NULL");
$result2 = mysqli_query($mysqli, "SELECT films.name_film, DATE_FORMAT(seanses.date_seans, '%Y-%m-%d %H:%i') AS d, zals.name_zal 
FROM films JOIN seanses ON seanses.id_film=films.id_film
JOIN zals ON zals.id_zal=seanses.id_zal
WHERE seanses.id_seans=$id");
$resultData = mysqli_fetch_assoc($result2);
$name = $resultData['name_film'];
$data = $resultData['d'];
$zal = $resultData['name_zal'];
?>

<html>
<head>
    <meta charset="UTF-8">
	<link href="main.css" rel="stylesheet">
	<title>Покупка</title>
</head>

<body>
    <h2><?php echo " ".$name; echo ", ".$data; echo ", Зал ".$zal?></h2>

    <table width='80%'>
		<tr class="hat">
            <td><strong>Ряд</strong></td>
            <td><strong>Место</strong></td>
			<td><strong>Стоимость</strong></td>
            <td><strong>Покупка</strong></td>
		</tr>
		<?php
		while ($res = mysqli_fetch_assoc($result)) {
            echo "<tr>";
			echo "<td>".$res['ryad']."</td>";
            echo "<td>".$res['mesto']."</td>";
            echo "<td>".$res['stoimost']."</td>";
            echo "<td><a href=\"action.php?id=$res[id_bilet]\" onClick=\"return confirm('Купить билет?')\">Купить</a></td>";
            echo "</tr>";
		}
		?>
	</table>
    <h2><a href="index.php">К выбору фильмов</a><h2>
</body>
</html>