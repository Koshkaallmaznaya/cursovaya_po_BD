<?php
require_once("dbConnection.php");
$id = $_GET['id'];
$result = mysqli_query($mysqli, 
"SELECT DATE_FORMAT(seanses.date_seans, '%Y-%m-%d %H:%i') AS d, films.name_film, zals.name_zal, seanses.id_seans
FROM seanses JOIN films ON films.id_film=seanses.id_film 
JOIN zals ON seanses.id_zal=zals.id_zal
WHERE seanses.id_film=$id");
$result2 = mysqli_query($mysqli, "SELECT name_film FROM films WHERE id_film=$id");
$resultData = mysqli_fetch_assoc($result2);
$text = $resultData['name_film'];
?>

<html>
<head>
    <meta charset="UTF-8">
	<link href="main.css" rel="stylesheet">
	<title>Сеансы</title>
</head>

<body>
    <h1><?php echo $text?></h1>

    <table width='80%'>
		<tr class="hat">
            <td><strong>Дата и время</strong></td>
			<td><strong>Зал</strong></td>
			<td><strong>Стоимость от...</strong></td>
		</tr>
		<?php
		while ($res = mysqli_fetch_assoc($result)) {
            echo "<tr>";
			echo "<td>".$res['d']."</td>";
            echo "<td><a href=\"pokupka.php?id=$res[id_seans]\">".$res['name_zal']."</a>";
            echo "<td>100</td>";
			echo "</tr>";
		}
		?>
	</table>
    <h2><a href="index.php">К выбору фильмов</a><h2>
</body>
</html>